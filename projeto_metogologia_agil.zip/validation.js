function validateIfNull(element){
    if (element){
        return true;
    }
    return false;
}